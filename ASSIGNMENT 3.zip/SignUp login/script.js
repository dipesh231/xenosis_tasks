document.addEventListener('DOMContentLoaded', () => {
    const signupForm = document.getElementById('signup-form');
    const signinForm = document.getElementById('signin-form');
    const errorMessage = document.getElementById('error-message');
    const logoutButton = document.getElementById('logout-button');
    const dashboardUsername = document.getElementById('username');

    if (signupForm) {
        signupForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm-password').value;

            if (password !== confirmPassword) {
                errorMessage.textContent = 'Passwords do not match.';
                return;
            }

            const user = {
                username,
                email,
                password
            };

            localStorage.setItem(email, JSON.stringify(user));
            alert('Account created successfully!');
            window.location.href = 'signin.html';
        });
    }

    if (signinForm) {
        signinForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            const storedUser = localStorage.getItem(email);
            if (storedUser) {
                const user = JSON.parse(storedUser);
                if (user.password === password) {
                    sessionStorage.setItem('currentUser', email);
                    window.location.href = 'dashboard.html';
                } else {
                    errorMessage.textContent = 'Incorrect password.';
                }
            } else {
                errorMessage.textContent = 'No account found with this email.';
            }
        });
    }

    if (logoutButton) {
        logoutButton.addEventListener('click', () => {
            sessionStorage.removeItem('currentUser');
            window.location.href = 'signin.html';
        });
    }

    if (dashboardUsername) {
        const currentUserEmail = sessionStorage.getItem('currentUser');
        if (currentUserEmail) {
            const user = JSON.parse(localStorage.getItem(currentUserEmail));
            dashboardUsername.textContent = user.username;
        } else {
            window.location.href = 'signup.html';
        }
    }
});
